function [KX] = kernel_linear(X1,X2)    
    KX = X1.'*X2;
end

